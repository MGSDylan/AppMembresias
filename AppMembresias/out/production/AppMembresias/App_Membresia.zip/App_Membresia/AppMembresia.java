package App_Membresia;
import model.*;
import model.util.Club;
import model.util.Rol;

import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class AppMembresia {
    private static Scanner scanner = new Scanner(System.in);
    private static boolean acceso = false;
    private static Club club=new Club();
    private static Membresia membresia=new Membresia();

    public static void main(String[] args) {

        logging();
        if (acceso){
            boolean salir = false;

            while (!salir) {

                int opcion = scanner.nextInt();
                scanner.nextLine();

                switch (opcion) {
                    case 1:
                        mostrarMenuCliente();
                        break;
                    case 2:
                        mostrarMenuReserva();
                        break;
                    case 3:
                        mostrarMenuPago();
                        break;
                    case 4:
                        salir = true;
                        System.out.println("Saliendo del sistema...");
                        break;
                    default:
                        System.out.println("Opción no válida. Intente de nuevo.");


                }
            }
        }

    }

    private static void logging()   {
        System.out.println("\n*** SISTEMA DE MEMBRESÍAS ***");
        System.out.println("\n Loggin...");
        System.out.println("\nIntroducir User");
        String user=scanner.nextLine();
        System.out.println("\nIntroducir Password");
        String password=scanner.nextLine();
        //controlar el input sea int
        System.out.println("Seleccione Rol");
        System.out.println("1.-Administrador");
        System.out.println("2.-Empleado");
        System.out.println("\nSeleccione un Rol");
        int rol=scanner.nextInt();
        
        Usuario user1 = switch (rol) {
            case 1 -> new Administrador(user, password, Rol.ADMINISTRADOR);
            case 2 -> new Empleado(user, password, Rol.EMPLEADO);
            default -> null;
        };

        if (user1 == null){
            System.out.println("Rol Invalido!!!!!");
        }else if (user1.iniciarSesion(user,password)){
            acceso=true;
            mostrarMenuPrincipal();
            }

    }



    private static void mostrarMenuPrincipal() {
        System.out.println("\n*** SISTEMA DE MEMBRESÍAS ***");

        System.out.println("1. Cliente");
        System.out.println("2. Reservar");
        System.out.println("3. Pagos");
        System.out.println("4. Salir");
        System.out.print("Seleccione una opción: ");
    }

    private static void mostrarMenuCliente() {
        System.out.println("\n*** CLIENTE ***");
        System.out.println("1. Registro (nombre, apellido, dirección, teléfono, correo)");
        System.out.println("2. Lista Clientes");
        System.out.println("3. Actualizar");
        System.out.println("4. Eliminar");
        System.out.println("5. Consultar por Dni");
        System.out.println("6. Regresar");
        System.out.print("Seleccione una opción: ");
        int opcion = scanner.nextInt();
        scanner.nextLine();


        switch (opcion) {
            case 1:
                System.out.println("Registro de cliente...");
                System.out.println("1. Registro (dni, nombre, direccion, teléfono, correo)");
                System.out.println("Ingrese Numero de Dni: ");
                String dni= scanner.nextLine();
                System.out.println("Ingrese Numero de Nombre: ");
                String nombre= scanner.nextLine();
                System.out.println("Ingrese Numero de Direccion: ");
                String direccion= scanner.nextLine();
                System.out.println("Ingrese Numero de Telefono: ");
                String telefono= scanner.nextLine();
                System.out.println("Ingrese Numero de Correo: ");
                String correoElectronico= scanner.nextLine();
                club.registrarCliente(dni,nombre,direccion,telefono,correoElectronico);
                // se implementara la funcionalidad
                mostrarMenuCliente();
                break;
            case 2:
                System.out.println("Lista de clientes...");
                // se implementara la funcionalidad
                club.getClientes().forEach(System.out::println);
                mostrarMenuCliente();
                break;
            case 3:
                System.out.println("Actualización de cliente...");
                // se implementara la funcionalidad
                System.out.println("Ingrese Numero de Dni: ");
                String dniUpdate= scanner.nextLine();

                if ((club.consultarCliente(dniUpdate))!=null){
                    System.out.println("Ingrese Numero de Nombre: ");
                    String nombreUpdate= scanner.nextLine();
                    System.out.println("Ingrese Numero de Direccion: ");
                    String direccionUpdate= scanner.nextLine();
                    System.out.println("Ingrese Numero de Telefono: ");
                    String telefonoUpdate= scanner.nextLine();
                    System.out.println("Ingrese Numero de Correo: ");
                    String correoElectronicoUpdate= scanner.nextLine();
                    club.actualizarCliente(dniUpdate,nombreUpdate,direccionUpdate,telefonoUpdate,correoElectronicoUpdate);
                    mostrarMenuCliente();
                }
                break;
            case 4:
                System.out.println("Eliminación de cliente...");
                // se implementara la funcionalidad
                System.out.println("Actualización de cliente...");
                // se implementara la funcionalidad
                System.out.println("Ingrese Numero de Dni: ");
                String dniDelete= scanner.nextLine();

                if ((club.consultarCliente(dniDelete))!=null){
                    club.eliminarCliente(dniDelete);

                }
                mostrarMenuCliente();
                break;
            case 5:
                System.out.println("Consultar cliente  por Dni ...");
                // se implementara la funcionalidad
                System.out.println("Ingrese Numero de Dni: ");
                String dniConsulta= scanner.nextLine();
                Cliente cl= club.consultarCliente(dniConsulta);
                System.out.println(cl);
                System.out.println(cl.getCodigoMiembro());
                mostrarMenuCliente();
                break;

            case 6:
                // Regresar al menú principal
                mostrarMenuPrincipal();
                break;
            default:
                System.out.println("Opción no válida. Intente de nuevo.");
        }
    }

    private static void mostrarMenuReserva() {
        System.out.println("\n*** RESERVAR ***");
        System.out.println("1. Registrar reserva (String codigoMembresia,String servicio,String fecha,String hora,String detalles)");
        System.out.println("2. Listar reservas");
        System.out.println("3. Consultar por cliente");
        System.out.println("4. Actualizar reserva");
        System.out.println("5. Eliminar reserva");
        System.out.println("6. Regresar");
        System.out.print("Seleccione una opción: ");
        int opcion = scanner.nextInt();
        scanner.nextLine();


        switch (opcion) {
            case 1:
                System.out.println("Registro de reserva...");
                System.out.println("Ingrese codigo de Membresia: ");
                String codigoMembresia=scanner.nextLine();

                boolean mem= club.getClientes().stream().anyMatch(x->x.getCodigoMiembro().equals(codigoMembresia));
                if (mem){
                    System.out.println("Ingrese servicio: ");
                    String servicio=scanner.nextLine();
                    System.out.println("Ingrese fecha: ");
                    String fecha=scanner.nextLine();
                    System.out.println("Ingrese hora: ");
                    String hora=scanner.nextLine();
                    System.out.println("Ingrese detalles: ");
                    String detalles=scanner.nextLine();
                    membresia.registrarReserva(codigoMembresia,servicio,fecha,hora,detalles);
                    // se implementara la funcionalidad
                    mostrarMenuReserva();
                    break;
                }
                System.out.println("codigo de membresia no encontrado!!!");
                mostrarMenuReserva();
                break;
            case 2:
                System.out.println("Listar reservas...");
                // se implementara la funcionalidad
                membresia.listReserva().forEach(System.out::println);
                mostrarMenuReserva();
                break;
            case 3:
                System.out.println("Consultar reservas por cliente...");
                // se implementara la funcionalidad
                System.out.println("Ingrese codigo de Membresia: ");
                String codigoMembresia2=scanner.nextLine();
                boolean mem2= club.getClientes().stream().anyMatch(x->x.getCodigoMiembro().equals(codigoMembresia2));
                if (mem2){
                    System.out.println(membresia.consultarReserva(codigoMembresia2));
                    mostrarMenuReserva();
                    break;

                }
                System.out.println("codMembresia no encontrada!!!");
                mostrarMenuReserva();
                break;

            case 4:
                System.out.println("Actualización de reserva...");
                // se implementara la funcionalidad
                System.out.println("Ingrese codigo de Membresia: ");
                String codigoMembresiaupdate=scanner.nextLine();
                boolean memUpdate= club.getClientes().stream().anyMatch(x->x.getCodigoMiembro().equals(codigoMembresiaupdate));
                if (memUpdate){

                    System.out.println("Ingrese servicio: ");
                    String servicio=scanner.nextLine();
                    System.out.println("Ingrese fecha: ");
                    String fecha=scanner.nextLine();
                    System.out.println("Ingrese hora: ");
                    String hora=scanner.nextLine();
                    System.out.println("Ingrese detalles: ");
                    String detalles=scanner.nextLine();
                    membresia.ActualizarReserva(fecha,hora,servicio,detalles);
                    mostrarMenuReserva();
                    break;

                }
                System.out.println("codMembresia no encontrada!!!");
                mostrarMenuReserva();

                break;
            case 5:
                System.out.println("Eliminación de reserva...");
                // se implementara la funcionalidad
                System.out.println("Ingrese codigo de Membresia: ");
                String codigoMembresiaDelete=scanner.nextLine();
                boolean memDelete= club.getClientes().stream().anyMatch(x->x.getCodigoMiembro().equals(codigoMembresiaDelete));
                if (memDelete){
                    System.out.println("Ingrese el servicio de la reserva a eliminar: ");
                    String servicio=scanner.nextLine();
                    membresia.eliminarReserva(servicio);
                    mostrarMenuReserva();
                    break;
                }

                mostrarMenuReserva();
                break;
            case 6:
                // Regresar al menú principal
                mostrarMenuPrincipal();
                break;
            default:
                System.out.println("Opción no válida. Intente de nuevo.");
        }
    }

    private static void mostrarMenuPago() {
        System.out.println("\n*** PAGOS ***");
        System.out.println("1. Registrar pago (membresía o otros)");
        System.out.println("2. Consultar pagos");
        System.out.println("3. Actualizar pagos");
        System.out.println("4. Eliminar pagos");
        System.out.println("5. Regresar");
        System.out.print("Seleccione una opción: ");
        int opcion = scanner.nextInt();
        scanner.nextLine();


        switch (opcion) {
            case 1:
                System.out.println("Registro de pago...");
                // se implementara la funcionalidad
                break;
            case 2:
                System.out.println("Consulta de pagos...");
                // se implementara la funcionalidad
                break;
            case 3:
                System.out.println("Actualización de pagos...");
                // se implementara la funcionalidad
                break;
            case 4:
                System.out.println("Eliminación de pagos...");
                // se implementara la funcionalidad
                break;
            case 5:
                // Regresar al menú principal
                mostrarMenuPrincipal();
                break;
            default:
                System.out.println("Opción no válida. Intente de nuevo.");
        }
    }
}
